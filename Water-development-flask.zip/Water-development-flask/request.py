import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'D.O. (mg/l':5.7, 'PH':7.2, 'CONDUCTIVITY (µmhos/cm)':189, 'B.O.D. (mg/l)':2,'FECAL COLIFORM (MPN/100ml)':4953})

print(r.json())
